const { DataTypes } = require('sequelize');
const sequelize = require('../config/db'); // Aseg�rate de que la configuraci�n de la DB est� correctamente importada

const Pedido = sequelize.define('Pedido', {
  // Definir las columnas de la tabla "pedidos"
  cliente: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  cantidad: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  sabor: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  valor: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  tipo: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  estado: {
    type: DataTypes.STRING(50),
    allowNull: false,
    defaultValue: 'Por pagar' // Estado inicial por defecto
  },
  total: {
    type: DataTypes.INTEGER,
    allowNull: false,
    // Este valor ser� calculado en el backend antes de crear un pedido
  }
}, {
  // Opciones adicionales
  tableName: 'pedidos',
  timestamps: false // Si no deseas que Sequelize agregue campos "createdAt" y "updatedAt"
});

// Sincroniza el modelo con la base de datos (si a�n no se ha creado la tabla)
Pedido.sync({ force: false })
  .then(() => {
    console.log('Modelo Pedido sincronizado correctamente.');
  })
  .catch(err => console.log('Error al sincronizar el modelo Pedido:', err));

module.exports = Pedido;
