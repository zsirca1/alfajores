const { DataTypes } = require('sequelize');
const sequelize = require('../config/db'); // Aseg�rate de que la configuraci�n de la DB est� correctamente importada

const Venta = sequelize.define('Venta', {
  // Definir las columnas de la tabla "ventas"
  cliente: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  cantidad: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  valor: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  tipo: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  estado: {
    type: DataTypes.STRING(50),
    allowNull: false,
    defaultValue: 'Por pagar' // Estado inicial por defecto
  },
  total: {
    type: DataTypes.INTEGER,
    allowNull: false,
    // Este valor ser� calculado en el backend antes de crear una venta
  }
}, {
  // Opciones adicionales
  tableName: 'ventas',
  timestamps: false // Si no deseas que Sequelize agregue campos "createdAt" y "updatedAt"
});

// Sincroniza el modelo con la base de datos (si a�n no se ha creado la tabla)
Venta.sync({ force: false })
  .then(() => {
    console.log('Modelo Venta sincronizado correctamente.');
  })
  .catch(err => console.log('Error al sincronizar el modelo Venta:', err));

module.exports = Venta;
