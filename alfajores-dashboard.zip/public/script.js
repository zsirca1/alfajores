// Variables de ventas y pedidos
let ventas = [];
let pedidos = [];
let precioSeleccionadoVenta = 0;
let precioSeleccionadoPedido = 0;

// Elementos del DOM
const ventaForm = document.getElementById("ventaForm");
const pedidoForm = document.getElementById("pedidoForm");
const ventasTable = document.getElementById("ventasTable");
const pedidosTable = document.getElementById("pedidosTable");
const precioFinal = document.getElementById("precioFinal");
const precioPedido = document.getElementById("precioPedido");

// Selecci�n de precios para venta
document.querySelectorAll("#ventaForm .botones-precio button").forEach(btn => {
  btn.addEventListener("click", () => {
    precioSeleccionadoVenta = parseInt(btn.dataset.precio);
    ventaForm.valor_unitario.value = precioSeleccionadoVenta;
    ventaForm.tipo_venta.value = btn.textContent;
    actualizarTotalVenta();
  });
});

// Selecci�n de precios para pedido
document.querySelectorAll("#pedidoForm .botones-precio button").forEach(btn => {
  btn.addEventListener("click", () => {
    precioSeleccionadoPedido = parseInt(btn.dataset.precio);
    pedidoForm.valor_unitario.value = precioSeleccionadoPedido;
    pedidoForm.tipo_venta.value = btn.textContent;
    actualizarTotalPedido();
  });
});

// Actualiza precio total en venta
function actualizarTotalVenta() {
  const cantidad = parseInt(ventaForm.cantidad.value || 0);
  const total = cantidad * precioSeleccionadoVenta;
  precioFinal.textContent = `$${total}`;
}

// Actualiza precio total en pedido
function actualizarTotalPedido() {
  const cantidad = parseInt(pedidoForm.cantidad.value || 0);
  const total = cantidad * precioSeleccionadoPedido;
  precioPedido.textContent = `$${total}`;
}

// Escucha cambios en cantidad
ventaForm.cantidad.addEventListener("input", actualizarTotalVenta);
pedidoForm.cantidad.addEventListener("input", actualizarTotalPedido);

// Registrar venta
ventaForm.addEventListener("submit", e => {
  e.preventDefault();
  const data = new FormData(ventaForm);
  const cliente = data.get("cliente").trim().toLowerCase();
  const metodo = data.get("metodo_pago");
  const cantidad = parseInt(data.get("cantidad"));
  const valor = parseInt(data.get("valor_unitario"));
  const tipo = data.get("tipo_venta");

  if (!cliente || !cantidad || !valor) return;

  const total = cantidad * valor;
  const estado = (metodo === "pendiente") ? "Por pagar" : "Pagado";

  // Agrupar por cliente y estado
  const existente = ventas.find(v =>
    v.cliente === cliente && v.estado === estado
  );

  if (existente) {
    existente.cantidad += cantidad;
    existente.total += total;
  } else {
    ventas.push({
      id: Date.now(),
      cliente,
      cantidad,
      valor,
      tipo,
      estado,
      total
    });
  }

  ventaForm.reset();
  precioSeleccionadoVenta = 0;
  precioFinal.textContent = "$0";
  renderVentas();
});

// Registrar pedido
pedidoForm.addEventListener("submit", e => {
  e.preventDefault();
  const data = new FormData(pedidoForm);
  const cliente = data.get("cliente").trim();
  const cantidad = parseInt(data.get("cantidad"));
  const sabor = data.get("sabor");
  const valor = parseInt(data.get("valor_unitario"));
  const tipo = data.get("tipo_venta");
  const estado = data.get("estado");

  if (!cliente || !cantidad || !valor || !sabor) return;

  pedidos.push({
    id: Date.now(),
    cliente,
    cantidad,
    sabor,
    valor,
    tipo,
    estado,
    total: cantidad * valor
  });

  pedidoForm.reset();
  precioSeleccionadoPedido = 0;
  precioPedido.textContent = "$0";
  renderPedidos();
});

// Renderizar tabla de ventas
function renderVentas() {
  ventasTable.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>X</th>
          <th>Cliente</th>
          <th>Cantidad</th>
          <th>Valor</th>
          <th>Estado</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        ${ventas.map(v => `
          <tr>
            <td><span class="delete-btn" onclick="eliminarVenta(${v.id})">X</span></td>
            <td>${v.cliente}</td>
            <td>${v.cantidad}</td>
            <td>$${v.valor}</td>
            <td><span class="${v.estado === 'Pagado' ? 'status-pagado' : 'status-pendiente'} edit-btn" onclick="toggleEstadoVenta(${v.id})">${v.estado}</span></td>
            <td>$${v.total}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

// Renderizar tabla de pedidos
function renderPedidos() {
  pedidosTable.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>X</th>
          <th>Cliente</th>
          <th>Cantidad</th>
          <th>Sabor</th>
          <th>Valor</th>
          <th>Estado</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        ${pedidos.map(p => `
          <tr>
            <td><span class="delete-btn" onclick="eliminarPedido(${p.id})">X</span></td>
            <td>${p.cliente}</td>
            <td>${p.cantidad}</td>
            <td>${p.sabor}</td>
            <td>$${p.valor}</td>
            <td><span class="${p.estado === 'Pagado' ? 'status-pagado' : 'status-pendiente'} edit-btn" onclick="toggleEstadoPedido(${p.id})">${p.estado}</span></td>
            <td>$${p.total}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

// Cambiar estado de venta
function toggleEstadoVenta(id) {
  const venta = ventas.find(v => v.id === id);
  if (venta) {
    venta.estado = (venta.estado === "Pagado") ? "Por pagar" : "Pagado";
    renderVentas();
  }
}

// Cambiar estado de pedido
function toggleEstadoPedido(id) {
  const pedido = pedidos.find(p => p.id === id);
  if (pedido) {
    pedido.estado = (pedido.estado === "Pagado") ? "Por pagar" : "Pagado";
    renderPedidos();
  }
}

// Eliminar venta
function eliminarVenta(id) {
  if (confirm("�Est�s seguro de eliminar esta venta?")) {
    ventas = ventas.filter(v => v.id !== id);
    renderVentas();
  }
}

// Eliminar pedido
function eliminarPedido(id) {
  if (confirm("�Est�s seguro de eliminar este pedido?")) {
    pedidos = pedidos.filter(p => p.id !== id);
    renderPedidos();
  }
}
