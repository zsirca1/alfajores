// routes/pedidoRoutes.js

const express = require('express');
const Pedido = require('../models/pedido');
const router = express.Router();

// Crear un nuevo pedido
router.post('/', async (req, res) => {
  try {
    const { cliente, cantidad, sabor, valor, tipo, estado } = req.body;
    const total = cantidad * valor;
    const nuevoPedido = await Pedido.create({ cliente, cantidad, sabor, valor, tipo, estado, total });
    res.status(201).json(nuevoPedido);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Obtener todos los pedidos
router.get('/', async (req, res) => {
  try {
    const pedidos = await Pedido.findAll();
    res.status(200).json(pedidos);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Actualizar el estado de un pedido
router.put('/:id', async (req, res) => {
  try {
    const pedido = await Pedido.findByPk(req.params.id);
    if (!pedido) return res.status(404).json({ error: 'Pedido no encontrado' });

    const { estado } = req.body;
    pedido.estado = estado;
    await pedido.save();
    res.status(200).json(pedido);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar un pedido
router.delete('/:id', async (req, res) => {
  try {
    const pedido = await Pedido.findByPk(req.params.id);
    if (!pedido) return res.status(404).json({ error: 'Pedido no encontrado' });

    await pedido.destroy();
    res.status(200).json({ message: 'Pedido eliminado' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
