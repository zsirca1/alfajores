// routes/ventaRoutes.js

const express = require('express');
const Venta = require('../models/venta');
const router = express.Router();

// Crear una nueva venta
router.post('/', async (req, res) => {
  try {
    const { cliente, cantidad, valor, tipo, estado } = req.body;
    const total = cantidad * valor;
    const nuevaVenta = await Venta.create({ cliente, cantidad, valor, tipo, estado, total });
    res.status(201).json(nuevaVenta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Obtener todas las ventas
router.get('/', async (req, res) => {
  try {
    const ventas = await Venta.findAll();
    res.status(200).json(ventas);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Actualizar el estado de una venta
router.put('/:id', async (req, res) => {
  try {
    const venta = await Venta.findByPk(req.params.id);
    if (!venta) return res.status(404).json({ error: 'Venta no encontrada' });

    const { estado } = req.body;
    venta.estado = estado;
    await venta.save();
    res.status(200).json(venta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar una venta
router.delete('/:id', async (req, res) => {
  try {
    const venta = await Venta.findByPk(req.params.id);
    if (!venta) return res.status(404).json({ error: 'Venta no encontrada' });

    await venta.destroy();
    res.status(200).json({ message: 'Venta eliminada' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
