const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Ruta para obtener todas las ventas
router.get("/ventas", (req, res) => {
  db.query("SELECT * FROM ventas", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Ruta para agregar una venta
router.post("/ventas", (req, res) => {
  const { cliente, cantidad, valor, tipo, estado } = req.body;
  db.query(
    "INSERT INTO ventas (cliente, cantidad, valor, tipo, estado) VALUES (?, ?, ?, ?, ?)",
    [cliente, cantidad, valor, tipo, estado],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ id: results.insertId, cliente, cantidad, valor, tipo, estado });
    }
  );
});

// Ruta para eliminar una venta
router.delete("/ventas/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM ventas WHERE id = ?", [id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: "Venta eliminada con �xito." });
  });
});

// Ruta para obtener todos los pedidos
router.get("/pedidos", (req, res) => {
  db.query("SELECT * FROM pedidos", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Ruta para agregar un pedido
router.post("/pedidos", (req, res) => {
  const { cliente, cantidad, sabor, valor, tipo, estado } = req.body;
  db.query(
    "INSERT INTO pedidos (cliente, cantidad, sabor, valor, tipo, estado) VALUES (?, ?, ?, ?, ?, ?)",
    [cliente, cantidad, sabor, valor, tipo, estado],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ id: results.insertId, cliente, cantidad, sabor, valor, tipo, estado });
    }
  );
});

// Ruta para eliminar un pedido
router.delete("/pedidos/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM pedidos WHERE id = ?", [id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: "Pedido eliminado con �xito." });
  });
});

module.exports = router;
